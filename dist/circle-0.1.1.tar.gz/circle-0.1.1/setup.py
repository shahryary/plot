from setuptools import setup

setup(
    name='circle',
    version='0.1.1',
    packages=['draw'],
    url='shahryary@github.com',
    license='GPL3',
    author='yadi',
    author_email='shahryary@gmail.com',
    description='plot circle',
    install_requires=['pillow']
    
)

readme

sudo apt-get install python3-tk 
